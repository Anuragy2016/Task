import React,{useEffect,useState} from 'react'
import _ from 'lodash'
import '../App.css';
import Modal from 'react-modal';
const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    minWidth: '400px',
    minHeight: '200px',
    padding:'0px !important'
  },
};

function MovieApp() {
  let [data,setData]=useState([])
  let[goldCost,setGoldCost]=useState(0)
  let[diamondCost,setDiamondCost]=useState(0)
  let[modalIsOpen, setIsOpen] =useState(false);
  let element=document.getElementsByClassName('free')
  function _removeClasses() {
    if(element&&element.length>0){
      element[0].classList.remove('free')
      if (element[0]) _removeClasses()
    }
   
  }
  function openModal() {
    setIsOpen(true);
    _removeClasses()
}

  function closeModal() {
    setIsOpen(false);
    setGoldCost(0)
    setDiamondCost(0)
  }

const freeSeatHandler=(item,i)=>{
  if(item.tname==='gold'&& diamondCost===0)
  {
    let price=goldCost
    let index=document.getElementById(i)
    if(index.classList.contains("free"))
    {
      index.classList.remove("free")
      price-=item.price
    }
    else{
      index.classList.add("free")
      price+=item.price
    }
    setGoldCost(price)
}
else if(item.tname==='diamond'&& goldCost===0)
{
  let price=diamondCost
  i=data[0].free+i
  let index=document.getElementById(i)
  
  if(index.classList.contains("free"))
  {
    index.classList.remove("free")
    price-=item.price
  }
  else{
    index.classList.add("free")
    price+=item.price
  }
  setDiamondCost(price)
}
else{
  _removeClasses()
  setDiamondCost(0)
  setGoldCost(0)
}
}
const getBlockedGoldSeat=(seats)=>{
  let card = [];
  if(data.length>0){
    _.times(seats.blocked, () => {
      card.push(<div className="blocked-gold" disabled={true} title={"Blocked"}></div>);
    });
  }
 return card
}
const getFreeGoldSeat=(seats)=>{
  let card = [];
  if(data.length>0){
    _.times(seats.free, (i) => {
      card.push(<div id={seats.tname==='gold'?i:data[0].free+i} section-name={seats.tname} key={i} className="free-gold" onClick={()=>freeSeatHandler(seats,i)}  title={"Free"}></div>);
    });
  }
 return card
}
const resetPrice=()=>{
  setGoldCost(0)
  setDiamondCost(0)
  _removeClasses()
}
useEffect(()=>{
  let data= [
  {"tname": "gold","free" : 10,"blocked": 20,"price": 200},
  {"tname": "diamond","free" : 5,"blocked": 30,"price": 500}]
  setData(data)
  },[])
  return (
   
    <div className="App">
         <Modal
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        style={customStyles}
        contentLabel="Example Modal"
      >
       <div className="model-view">
         <div className="model-header">Ticket Price</div>
       <div className="model-content">Total price : {goldCost>0?goldCost:diamondCost}</div>
       </div>
       <div className="button-block">
       <button className="button"onClick={closeModal}>close</button>
       </div>
        
      </Modal>
      <div className="gold-seat">
          {
          data.length>0? getBlockedGoldSeat(data[0]):""
          }
          {
          data.length>0?getFreeGoldSeat(data[0]):""
        }
      </div> 
      <div className="gold-seat">
          {
          data.length>0? getBlockedGoldSeat(data[1]):""
          }
          {
          data.length>0?getFreeGoldSeat(data[1]):""
        }
      </div> 
      <div className="button-block">
        <button className="button"  onClick={openModal}>Book Now</button>
        <button className="button" onClick={resetPrice}>Reset</button>
      </div>
         </div>
  );
}

export default MovieApp;
