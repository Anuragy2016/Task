import React from 'react'
import MovieApp from'./components/movie-app'

function App() {
  return (
   
    <div className="App">
      <div>
        <MovieApp />
      </div>
       
    </div>
  );
}

export default App;
