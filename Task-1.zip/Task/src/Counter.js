import React,{useState,useEffect} from 'react'
import './App.css';

function Counter() {
let [count,setCount]=useState(0)
const incrementHandler=()=>{
 count=count+3
 setCount(count)
}
const decrementHandler=()=>{
  count=count-3
  setCount(count)
}

  return (
    <div className="App">
       <div className="count-div"> 
        {/* <span>Count :</span> */}
      <span className="counter">{count}</span>
      </div>
       <div className="button-div">
       <button className="button-1" onClick={incrementHandler}>increment</button>
       <button className="button-2" onClick={decrementHandler}>decrement</button>
       </div> 
       {/* <div>{data?data:""}</div> */}
       <div>       
       </div>
      
    </div>
  );
}

export default Counter;
