import React,{useState,useEffect} from 'react'
import './App.css';

function GetData() {

let [data,setData]=useState([])
let [text,setText]=useState('')

const onChangeHandler=(event)=>{
setText(event.target.value)
}
const submitClicked=async()=>{
  console.log("text",text)
  const rawResponse = await fetch('https://gorest.co.in/public/v1/todos', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ title: text})
  });
  const content = await rawResponse.json();

  console.log(content);
}
useEffect(()=>{
  fetch('https://gorest.co.in/public/v1/todos')
  .then(response => response.json())
  .then(data => setData(data.data));
},[])
console.log("data", data)
  return (
    <div className="App">
       <div>
       <div className="grid-container">
         {
           data.map(item=>{
           
            return(
            <span className="grid-item">{item.id}{item.title}</span>
            )
             
           })
         }</div>
         <div >
           <input type="text" value={text} onChange={onChangeHandler} />
           <button onClick={submitClicked}>Submit</button>
         </div>
   
         
       </div>
      
    </div>
  );
}

export default GetData;
