import React from 'react'
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import './App.css';
import Counter from'./Counter';
import GetData from './GetData';
import history from './history'

function App() {
const handleClick=()=>{
  history.push('/Counter')
  // window.reload()
}
 
  return (
    <div className="App">
       <BrowserRouter>
             <Switch>
                <Route exact path="/Counter" component={Counter} /> 
                <Route exact path="/GetData" component={GetData} /> 
              
             </Switch>  
         </BrowserRouter>
         <button onClick={handleClick }>
         Counter
      </button>
      <button onClick={() =>  history.push('/GetData') }>
      GetData
      </button>
   
         
      {/* <Counter />
      <GetData />  */}
    </div>
  );
}

export default App;
